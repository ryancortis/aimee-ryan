Aimee & Ryan Premium Wedding Website

Upload everything in this ZIP to your GitHub repository.

Files included:
- index.html
- assets/ar-logo.png

Venue photo placeholders:
The design expects two venue photos:
- assets/church.jpg
- assets/palazzo-parisio.jpg

To add venue photos:
1. Upload your church photo to the assets folder and rename it exactly: church.jpg
2. Upload your Palazzo Parisio photo to the assets folder and rename it exactly: palazzo-parisio.jpg

RSVP:
The Google Form placeholders are still inside index.html:
- PASTE_GOOGLE_FORM_ACTION_URL_HERE
- entry.FULL_NAME_ENTRY_ID
- entry.ATTENDING_ENTRY_ID

Replace these once your Google Form is ready.
